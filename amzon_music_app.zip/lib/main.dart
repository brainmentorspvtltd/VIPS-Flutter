import 'package:flutter/material.dart';
import 'package:sangeet_music/screens/homeScreen.dart';
import 'package:sangeet_music/screens/loadingScreen.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    // home: const LoadingScreen(),
    // theme: ThemeData.dark(),
    initialRoute: '/',
    routes: {
      '/': (context) => const LoadingScreen(),
      '/home': (context) => const HomePage(),
    },
  ));
}
