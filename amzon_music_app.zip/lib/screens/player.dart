import 'package:flutter/material.dart';

class SongPlayer extends StatefulWidget {
  late String artWorkUrl;
  late String trackName;
  late String artistName;
  late String previewUrl;
  SongPlayer(
      {required this.artWorkUrl,
      required this.artistName,
      required this.previewUrl,
      required this.trackName,
      super.key});

  @override
  State<SongPlayer> createState() => _SongPlayerState();
}

class _SongPlayerState extends State<SongPlayer> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(15),
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height * 0.5,
            child: Image.network(
              widget.artWorkUrl,
              fit: BoxFit.cover,
            ),
          ),
          Text(
            widget.trackName,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(
            height: 10,
          ),
          Text(
            widget.artistName,
            style: const TextStyle(
                fontSize: 15, fontWeight: FontWeight.bold, color: Colors.grey),
          ),
          Slider(value: 1.0, onChanged: (value) {}),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              IconButton(onPressed: () {}, icon: const Icon(Icons.no_accounts)),
              IconButton(
                  onPressed: () {}, icon: const Icon(Icons.skip_previous)),
              IconButton(
                  onPressed: () {},
                  icon: const Icon(
                    Icons.play_arrow,
                    size: 80,
                  )),
              IconButton(onPressed: () {}, icon: const Icon(Icons.skip_next)),
              IconButton(onPressed: () {}, icon: const Icon(Icons.repeat)),
            ],
          )
        ],
      ),
    ));
  }
}
