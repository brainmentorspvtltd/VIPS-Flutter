part of 'counter_cubit.dart';

class CounterState {
  final int count;
  CounterState(this.count);
}
