import 'package:blocdemo/cubit/counter_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class CounterApp extends StatefulWidget {
  const CounterApp({super.key});

  @override
  State<CounterApp> createState() => CounterAppState();
}

class CounterAppState extends State<CounterApp> {
  int count = 0;
  @override
  Widget build(BuildContext context) {
    print("build is called $count times");
    return SafeArea(
        child: Scaffold(
      body: BlocListener<CounterCubit, CounterState>(
        listener: (context, state) {
          if (state.count > 0) {
            print("increment");
            ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Value incremented")));
          }
          if (state.count < 0) {
            print("decrement");

            ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Value decremented")));
          }
          ScaffoldMessenger.of(context)
              .showSnackBar(const SnackBar(content: Text("DEfault case")));
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            BlocBuilder<CounterCubit, CounterState>(
              // listener: (context, state) {
              //   if (state.count > 0) {
              //     print("increment");
              //     ScaffoldMessenger.of(context).showSnackBar(
              //         const SnackBar(content: Text("Value incremented")));
              //   }
              //   if (state.count < 0) {
              //     print("decrement");

              //     ScaffoldMessenger.of(context).showSnackBar(
              //         const SnackBar(content: Text("Value decremented")));
              //   }
              //   ScaffoldMessenger.of(context).showSnackBar(
              //       const SnackBar(content: Text("DEfault case")));
              // },
              builder: (context, state) {
                return Text(
                  "This is the current count: ${state.count}",
                  style: const TextStyle(fontSize: 30),
                );
              },
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                MaterialButton(
                  onPressed: () {
                    BlocProvider.of<CounterCubit>(context).increment();
                    // BlocProvider.of<CounterCubit>(context).add()
                    // setState(() {
                    //   count++;
                    // });
                  },
                  child: const Text("ADD"),
                ),
                MaterialButton(
                  onPressed: () {
                    BlocProvider.of<CounterCubit>(context).decrement();

                    // setState(() {
                    //   count--;
                    // });
                  },
                  child: const Text("SUB"),
                )
              ],
            )
          ],
        ),
      ),
    ));
  }
}
