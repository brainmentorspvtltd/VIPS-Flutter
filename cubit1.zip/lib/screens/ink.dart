import 'package:flutter/material.dart';

class InkDemo extends StatefulWidget {
  const InkDemo({super.key});

  @override
  State<InkDemo> createState() => _InkDemoState();
}

class _InkDemoState extends State<InkDemo> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            GestureDetector(
              onTap: () {
                print("This is the Gesture dectector");
              },
              child: Container(
                width: 100,
                height: 100,
                color: Colors.red,
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            InkWell(
              splashColor: Colors.amber,
              onTap: () {
                print("This is the inkwell");
              },
              child: Ink(
                width: 100,
                height: 100,
                color: Colors.green,
              ),
            )
          ],
        ),
      ),
    ));
  }
}
