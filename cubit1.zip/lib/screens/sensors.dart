import 'package:flutter/material.dart';
import 'package:sensors_plus/sensors_plus.dart';

class SensorsDemo extends StatefulWidget {
  const SensorsDemo({super.key});

  @override
  State<SensorsDemo> createState() => _SensorsDemoState();
}

class _SensorsDemoState extends State<SensorsDemo> {
  AccelerometerEvent? aEvent;
  MagnetometerEvent? mEvent;
  GyroscopeEvent? gEvent;

  getAccData() {
    accelerometerEvents.listen((event) {
      setState(() {
        aEvent = event;
        print("this is the acc data $event");
      });
    });
  }

  getMagData() {
    magnetometerEvents.listen((event) {
      setState(() {
        mEvent = event;
        print("this is the mag data $event");
      });
    });
  }

  getGyroData() {
    gyroscopeEvents.listen((event) {
      setState(() {
        gEvent = event;
        print("this is the gyro data $event");
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            MaterialButton(
              onPressed: () {
                // getAccData(); //acc data
                // getGyroData(); // gyrodata
                getMagData(); //magdata
              },
              child: const Text("Get Data"),
            )
          ],
        ),
      ),
    ));
  }
}
