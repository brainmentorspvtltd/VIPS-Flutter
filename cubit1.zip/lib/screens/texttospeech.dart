import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

class TTSDemo extends StatefulWidget {
  const TTSDemo({super.key});

  @override
  State<TTSDemo> createState() => _TTSDemoState();
}

class _TTSDemoState extends State<TTSDemo> {
  FlutterTts ttss = FlutterTts();
  speak(String data) async {
    List<dynamic> languages = await ttss.getLanguages;
    print("these are the lang $languages");
    await ttss.speak(data);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            MaterialButton(
              onPressed: () {
                speak("Kya haal hai");
              },
              child: const Text("START"),
            )
          ],
        ),
      ),
    ));
  }
}
