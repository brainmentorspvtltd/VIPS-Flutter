Stream<int> createStream() async* {
  for (int i = 1; i < 20; i++) {
    print("Noodle number $i is sent");
    await Future.delayed(const Duration(seconds: 5));
    yield i;
  }
}

void main() {
  Stream noodleStream = createStream();

  noodleStream.listen((noodleIndex) {
    print("Noodle number $noodleIndex is rec");
  });
}
