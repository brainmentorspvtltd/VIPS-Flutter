// class UserModel {
//   // cont
//   // name const
//   // method userObject Creation

//   touserOBJ{
//     Map<String, dynamic> userMap = {
//       "first name": firstName,
//       "last Name": lastName,
//       "phone number": phoneNumber,
//       "email add": regEmail,
//       "pass": regPassword
//     };
//     // return userMap;
//   }
// }

