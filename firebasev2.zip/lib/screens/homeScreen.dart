import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  String loginEmail;
  HomeScreen({required this.loginEmail, super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // String gg = "hfg";
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
        title: const Text("Home Page"),
        centerTitle: true,
      ),
      body: Center(
        child: Text("This is the login Email: ${widget.loginEmail}"),
      ),
    ));
  }
}
