import 'package:firebase_demo_2/screens/homeScreen.dart';
import 'package:firebase_demo_2/services/userAuth.dart';
import 'package:flutter/material.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final GlobalKey<FormFieldState> _formKey = GlobalKey();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  UserAuth firebaseAuth = UserAuth();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: Form(
          key: _formKey,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                TextFormField(
                  decoration:
                      const InputDecoration(hintText: "Enter your Email"),
                  controller: emailController,
                ),
                TextFormField(
                  decoration:
                      const InputDecoration(hintText: "Enter your Password"),
                  controller: passwordController,
                ),
                OutlinedButton(
                    onPressed: () async {
                      String loginEmail = await firebaseAuth.loginUser(
                          loginEmail: emailController.text,
                          loginPassword: passwordController.text);
                      // ignore: use_build_context_synchronously
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  HomeScreen(loginEmail: loginEmail)));
                    },
                    child: const Text("Login Now"))
              ],
            ),
          )),
    ));
  }
}
