import 'package:firebase_demo_2/screens/loginPage.dart';
import 'package:firebase_demo_2/services/userAuth.dart';
import 'package:flutter/material.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final GlobalKey<FormFieldState> _formKey = GlobalKey();
  TextEditingController firstNameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  TextEditingController phoneNumberController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  UserAuth firebaseAuth = UserAuth();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: Form(
          key: _formKey,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                // const TextField(),
                TextFormField(
                  decoration:
                      const InputDecoration(hintText: "Enter your First Name"),
                  controller: firstNameController,
                ),
                TextFormField(
                  decoration:
                      const InputDecoration(hintText: "Enter your Last Name"),
                  controller: lastNameController,
                ),
                TextFormField(
                  decoration: const InputDecoration(
                      hintText: "Enter your Phone Number"),
                  controller: phoneNumberController,
                  validator: (phone) {
                    if (phone!.length != 10) {
                      return "Please enter a valid phone number";
                    }
                    return null;
                  },
                ),
                TextFormField(
                  decoration:
                      const InputDecoration(hintText: "Enter your Email"),
                  controller: emailController,
                ),
                TextFormField(
                  decoration:
                      const InputDecoration(hintText: "Enter your Password"),
                  controller: passwordController,
                ),
                OutlinedButton(
                    onPressed: () async {
                      // _formKey.currentState!.validate();
                      String userEmail = await firebaseAuth.regiserUser(
                          firstName: firstNameController.text,
                          lastName: lastNameController.text,
                          phoneNumber: phoneNumberController.text,
                          registerEmail: emailController.text,
                          registerPassword: passwordController.text);

                      print(
                          "The user is successfully registerd with the given email address: $userEmail");
                    },
                    child: const Text("Register Now")),
                OutlinedButton(
                    onPressed: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (_) => const LoginPage()));
                    },
                    child: const Text("Go to Login Page"))
              ],
            ),
          )),
    ));
  }
}
