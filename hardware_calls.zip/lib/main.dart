import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:h_calls/screens/MIC.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MaterialApp(
    // home: FlutterGPSDemo(),
    // home: FlutterCameraDemo(),
    home: FlutterMICDemo(),
    // home: AuthScreen(),
  ));
}
