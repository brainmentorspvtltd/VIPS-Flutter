import 'package:camera/camera.dart';
import 'package:flutter/material.dart';

class FlutterCameraDemo extends StatefulWidget {
  const FlutterCameraDemo({super.key});

  @override
  State<FlutterCameraDemo> createState() => _FlutterCameraDemoState();
}

class _FlutterCameraDemoState extends State<FlutterCameraDemo> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initializeCameras();
  }

  initializeCameras() async {
    cameras = await availableCameras();
    print("These are the avl cameras on this device $cameras");
  }

  late List<CameraDescription> cameras;
  late CameraController camController;
  bool isCameraRunning = false;

  openCamera() async {
    camController = CameraController(cameras[0], ResolutionPreset.medium);
    await camController.initialize();
    setState(() {
      isCameraRunning = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            isCameraRunning
                ? CameraPreview(camController)
                : const Text("The camera is not running yet"),
            OutlinedButton(
                onPressed: () async {
                  XFile captImage = await camController.takePicture();
                  // storeImageToGallery(captImage);
                  openCamera();
                },
                child: const Text("Open Camera"))
          ],
        ),
      ),
    ));
  }
}
