import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';

class FlutterGPSDemo extends StatefulWidget {
  const FlutterGPSDemo({super.key});

  @override
  State<FlutterGPSDemo> createState() => _FlutterGPSDemoState();
}

class _FlutterGPSDemoState extends State<FlutterGPSDemo> {
  double latitude = 0.0;
  double longitude = 0.0;
  getGPSData() async {
    PermissionStatus gpsPermission = await Permission.location.request();
    Position currentPositon = await Geolocator.getCurrentPosition();

    setState(() {
      latitude = currentPositon.latitude;
      longitude = currentPositon.longitude;
    });
    print(
        "This is the data from the GPS ${currentPositon.latitude} and ${currentPositon.longitude}");
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Text("Lat: ${latitude.toString()}"),
            Text("Lon: ${longitude.toString()}"),
            OutlinedButton(
                onPressed: () {
                  getGPSData();
                },
                child: const Text("GET GPS DATA")),
          ],
        ),
      ),
    ));
  }
}
