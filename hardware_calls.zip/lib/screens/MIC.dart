import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:speech_to_text/speech_to_text.dart';

class FlutterMICDemo extends StatefulWidget {
  const FlutterMICDemo({super.key});

  @override
  State<FlutterMICDemo> createState() => _FlutterMICDemoState();
}

class _FlutterMICDemoState extends State<FlutterMICDemo> {
  String? selectedOption = 'Option 1'; // Default selected option
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initializeMic();
  }

  initializeMic() async {
    PermissionStatus micPermission = await Permission.microphone.request();
    if (micPermission.isGranted) {
      print("Mic is allowed");
      await _speech.initialize();
    } else if (micPermission.isDenied) {
      print("Mic is Denied");
    } else if (micPermission.isPermanentlyDenied) {
      print("Mic is permanently denied");

      await openAppSettings();
    }
  }

  startMic() {
    _speech.listen(onResult: (listenValue) {
      setState(() {
        micData = listenValue.recognizedWords;
      });
    });
  }

  stopMic() {}

  String micData = '';
  final SpeechToText _speech = SpeechToText();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
        title: const Text('Drawer Example'),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text(
                'Drawer Header',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.home),
              title: const Text('Home'),
              onTap: () {
                // Handle drawer item tap
              },
            ),
            ListTile(
              leading: const Icon(Icons.settings),
              title: const Text('Settings'),
              onTap: () {
                // Handle drawer item tap
              },
            ),
          ],
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            DropdownButton<String>(
              value: selectedOption,
              onChanged: (newValue) {
                setState(() {
                  selectedOption = newValue;
                });
              },
              items: const [
                DropdownMenuItem(
                  value: "Option 1", // Use a unique value for each option
                  child: Text("Option 1"),
                ),
                DropdownMenuItem(value: "hi", child: Text("hi")),
                DropdownMenuItem(value: "hey", child: Text("hey")),
              ],
            ),

            // DropdownButton<String>(
            //   value: selectedOption,
            //   onChanged: (newValue) {
            //     setState(() {
            //       selectedOption = newValue;
            //     });
            //   },
            //   items: [
            //     DropdownMenuItem(
            //         value: selectedOption, child: const Text("Option 1")),
            //     const DropdownMenuItem(value: "hi", child: Text("hi")),
            //     const DropdownMenuItem(value: "hey", child: Text("hey")),
            //   ],
            // ),
            const SizedBox(height: 20),
            Text('Selected Option: $selectedOption'),
            Text("This is the data from MIC: $micData"),
            OutlinedButton(
                onPressed: () {
                  startMic();
                },
                child: const Text("Start Listening"))
          ],
        ),
      ),
    ));
  }
}
