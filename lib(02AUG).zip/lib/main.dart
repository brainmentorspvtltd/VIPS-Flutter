// // import 'package:flutter/material.dart';

// // void main() {
// //   runApp(
// //     MaterialApp(
// //         // theme: ThemeData.dark(),
// //         home: Scaffold(
// //             appBar: AppBar(
// //               // leading: const Icon(Icons.battery_1_bar),
// //               leading: const Row(
// //                 children: [
// //                   SizedBox(
// //                     width: 20,
// //                   ),
// //                   Icon(Icons.search),
// //                 ],
// //               ),
// //               title: const Text(
// //                 "YouTube",
// //                 style:
// //                     TextStyle(fontWeight: FontWeight.bold, color: Colors.red),
// //               ),
// //               centerTitle: true,
// //               actions: const [
// //                 Icon(Icons.search),
// //                 SizedBox(
// //                   width: 20,
// //                 ),
// //                 Icon(Icons.video_call),
// //                 Icon(Icons.add)
// //               ],
// //             ),
// //             // body: const Center(child: Text('HELLO THIS IS FLUTTER')),
// //             body: const Column(
// //               crossAxisAlignment: CrossAxisAlignment.center,
// //               children: [
// //                 Text(
// //                   "First Child",
// //                   style: TextStyle(fontSize: 50),
// //                 ),
// //                 Text(
// //                   "Second Child",
// //                   style: TextStyle(fontSize: 50),
// //                 ),
// //                 Text(
// //                   "Third Child",
// //                   style: TextStyle(fontSize: 50),
// //                 ),
// //                 Text(
// //                   "Fourth Child",
// //                   style: TextStyle(fontSize: 50),
// //                 ),
// //                 Row(
// //                   children: [
// //                     Text(
// //                       "First Child",
// //                       style: TextStyle(fontSize: 19),
// //                     ),
// //                     Text(
// //                       "Second Child",
// //                       style: TextStyle(fontSize: 19),
// //                     )
// //                   ],
// //                 )
// //               ],
// //             ))),
// //   );
// // }

// import 'package:flutter/material.dart';

// void main() {
//   runApp(
//     MaterialApp(
//         // theme: ThemeData.dark(),
//         home: Scaffold(
//             appBar: AppBar(
//               // leading: const Icon(Icons.battery_1_bar),
//               leading: const Row(
//                 children: [
//                   SizedBox(
//                     width: 20,
//                   ),
//                   Icon(Icons.search),
//                 ],
//               ),
//               title: const Text(
//                 "YouTube",
//                 style:
//                     TextStyle(fontWeight: FontWeight.bold, color: Colors.red),
//               ),
//               centerTitle: true,
//               actions: const [
//                 Icon(Icons.search),
//                 SizedBox(
//                   width: 20,
//                 ),
//                 Icon(Icons.video_call),
//                 Icon(Icons.add)
//               ],
//             ),
//             // body: const Center(child: Text('HELLO THIS IS FLUTTER')),
//             body: Column(
//               mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//               children: [
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                   children: [
//                     Container(
//                       height: 150,
//                       width: 100,
//                       decoration: BoxDecoration(
//                           color: Colors.red,
//                           border: Border.all(width: 2),
//                           // border: Border.all(width: 20),
//                           borderRadius:
//                               const BorderRadius.all(Radius.circular(20))),
//                       // child: Image.asset("assets/orange.jpg"),
//                       child: Column(
//                         children: [
//                           Image.asset("assets/orange.jpg"),
//                           const Text(
//                             "ORANGE",
//                             style: TextStyle(
//                                 color: Colors.white,
//                                 fontWeight: FontWeight.bold),
//                           )
//                         ],
//                       ),
//                     ),
//                     // Container(
//                     //   height: 150,
//                     //   width: 100,
//                     //   decoration: BoxDecoration(
//                     //       color: Colors.yellow,
//                     //       border: Border.all(width: 2),
//                     //       // border: Border.all(width: 20),
//                     //       borderRadius:
//                     //           const BorderRadius.all(Radius.circular(20))),
//                     // ),
//                     itemContainer(
//                         containerColor: Colors.black,
//                         textData: "HELLO THIS IS CONT"),

//                     itemContainer(containerColor: Colors.green, textData: "22"),
//                     itemContainer(containerColor: Colors.yellow, textData: "44")
//                   ],
//                 ),
//                 // Row(
//                 //   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                 //   children: [
//                 //     Container(
//                 //       height: 150,
//                 //       width: 100,
//                 //       decoration: BoxDecoration(
//                 //           color: Colors.red,
//                 //           border: Border.all(width: 2),
//                 //           // border: Border.all(width: 20),
//                 //           borderRadius:
//                 //               const BorderRadius.all(Radius.circular(20))),
//                 //     ),
//                 //     Container(
//                 //       height: 150,
//                 //       width: 100,
//                 //       decoration: BoxDecoration(
//                 //           color: Colors.yellow,
//                 //           border: Border.all(width: 2),
//                 //           // border: Border.all(width: 20),
//                 //           borderRadius:
//                 //               const BorderRadius.all(Radius.circular(20))),
//                 //     ),
//                 //     Container(
//                 //       height: 150,
//                 //       width: 100,
//                 //       decoration: BoxDecoration(
//                 //           color: Colors.blue,
//                 //           border: Border.all(width: 2),
//                 //           // border: Border.all(width: 20),
//                 //           borderRadius:
//                 //               const BorderRadius.all(Radius.circular(20))),
//                 //     )
//                 //   ],
//                 // ),
//                 const Row(),
//                 const Row()
//               ],
//             ))),
//   );
// }

// Container itemContainer(
//     {Color? containerColor, required String textData, double cHeight = 20}) {
//   return Container(
//     height: cHeight,
//     width: 100,
//     decoration: BoxDecoration(
//         color: containerColor,
//         border: Border.all(width: 2),
//         // border: Border.all(width: 20),
//         borderRadius: const BorderRadius.all(Radius.circular(20))),
//     child: Center(
//         child: Text(
//       textData,
//       style: const TextStyle(color: Colors.white),
//     )),
//   );
// }

// // import 'package:flutter/material.dart';

// // void main() {
// //   runApp(
// //     MaterialApp(
// //         // theme: ThemeData.dark(),
// //         home: Scaffold(
// //             appBar: AppBar(
// //               // leading: const Icon(Icons.battery_1_bar),
// //               leading: const Row(
// //                 children: [
// //                   SizedBox(
// //                     width: 20,
// //                   ),
// //                   Icon(Icons.search),
// //                 ],
// //               ),
// //               title: const Text(
// //                 "YouTube",
// //                 style:
// //                     TextStyle(fontWeight: FontWeight.bold, color: Colors.red),
// //               ),
// //               centerTitle: true,
// //               actions: const [
// //                 Icon(Icons.search),
// //                 SizedBox(
// //                   width: 20,
// //                 ),
// //                 Icon(Icons.video_call),
// //                 Icon(Icons.add)
// //               ],
// //             ),
// //             // body: const Center(child: Text('HELLO THIS IS FLUTTER')),
// //             body: Center(
// //                 child: Stack(
// //               alignment: Alignment.center,
// //               children: [
// //                 Container(
// //                   height: 300,
// //                   width: 300,
// //                   color: Colors.yellow,
// //                 ),
// //                 Positioned(
// //                   right: 0,
// //                   child: Container(
// //                     height: 200,
// //                     width: 200,
// //                     color: Colors.red,
// //                   ),
// //                 ),
// //                 Positioned(
// //                   top: 0,
// //                   left: 0,
// //                   child: Container(
// //                     height: 100,
// //                     width: 100,
// //                     color: Colors.blue,
// //                   ),
// //                 )
// //               ],
// //             )))),
// //   );
// // }

// // import 'package:flutter/material.dart';

// // void main() {
// //   runApp(
// //     MaterialApp(
// //         // theme: ThemeData.dark(),
// //         home: Scaffold(
// //             floatingActionButton: FloatingActionButton(
// //               elevation: 20,
// //               onPressed: () {
// //                 print("FAB is clicked");
// //               },
// //               child: const Icon(Icons.edit),
// //             ),
// //             floatingActionButtonLocation:
// //                 FloatingActionButtonLocation.centerFloat,
// //             // floatingActionButtonLocation: FloatingActionButtonLocation.startTop,
// //             appBar: AppBar(
// //               // leading: const Icon(Icons.battery_1_bar),
// //               leading: const Row(
// //                 children: [
// //                   SizedBox(
// //                     width: 20,
// //                   ),
// //                   Icon(Icons.search),
// //                 ],
// //               ),
// //               title: const Text(
// //                 "YouTube",
// //                 style:
// //                     TextStyle(fontWeight: FontWeight.bold, color: Colors.red),
// //               ),
// //               centerTitle: true,
// //               actions: const [
// //                 Icon(Icons.search),
// //                 SizedBox(
// //                   width: 20,
// //                 ),
// //                 Icon(Icons.video_call),
// //                 Icon(Icons.add)
// //               ],
// //             ),
// //             // body: const Center(child: Text('HELLO THIS IS FLUTTER')),
// //             body: Center(
// //                 child: IconButton(
// //                     onPressed: () {
// //                       print("THE ICON BUTTON IS TAPPED");
// //                     },
// //                     icon: const Icon(Icons.add))))),
// //   );
// // }

import 'package:demoapp02/screens/secondPage.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    // home: FirstPage(),
    home: COUNTER(),
  ));
}
