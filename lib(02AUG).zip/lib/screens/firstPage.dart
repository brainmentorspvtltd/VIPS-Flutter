import 'package:demoapp02/shared/widgets/buttons.dart';
import 'package:demoapp02/shared/widgets/itemContainer.dart';
import 'package:flutter/material.dart';

class FirstPage extends StatelessWidget {
  const FirstPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          // leading: const Icon(Icons.battery_1_bar),
          leading: const Row(
            children: [
              SizedBox(
                width: 20,
              ),
              Icon(Icons.search),
            ],
          ),
          title: const Text(
            "YouTube",
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.red),
          ),
          centerTitle: true,
          actions: const [
            Icon(Icons.search),
            SizedBox(
              width: 20,
            ),
            Icon(Icons.video_call),
            Icon(Icons.add)
          ],
        ),
        // body: const Center(child: Text('HELLO THIS IS FLUTTER')),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ItemContainer(
                  containerColor: Colors.red,
                  textData: "FIRST",
                ),
                ItemContainer(
                  containerColor: Colors.green,
                  textData: "SECOND",
                ),
                ItemContainer(
                  containerColor: Colors.black,
                  textData: "THIRD",
                ),
                ItemContainer(
                  containerColor: Colors.cyan,
                  textData: "FOURH",
                )
              ],
            ),
            Row(
              children: [
                MYBUTTON(buttonIcon: Icons.add),
                MYBUTTON(
                  buttonIcon: Icons.remove,
                )
              ],
            )
          ],
        ));
  }
}
