import 'package:flutter/material.dart';

class COUNTER extends StatefulWidget {
  const COUNTER({super.key});

  @override
  State<COUNTER> createState() => _COUNTERState();
}

class _COUNTERState extends State<COUNTER> {
  int count = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          count++;
          print("This is the current val of count $count");
          setState(() {});
        },
        child: const Text("ADD"),
      ),
      body: Container(
        // width: 400,
        width: MediaQuery.of(context).size.width,
        color: Colors.green,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              "THIS IS THE COUNT",
              style: TextStyle(color: Colors.white, fontSize: 30),
            ),
            Text(
              "COUNT: ${count.toString()}",
              style: const TextStyle(color: Colors.white, fontSize: 30),
            ),
          ],
        ),
      ),
    );
  }
}
