import 'package:flutter/material.dart';

class MYBUTTON extends StatelessWidget {
  IconData buttonIcon;
  MYBUTTON({super.key, required this.buttonIcon});

  @override
  Widget build(BuildContext context) {
    return IconButton(onPressed: () {}, icon: Icon(buttonIcon));
  }
}
