import 'package:flutter/material.dart';

class ItemContainer extends StatelessWidget {
  Color containerColor;
  String textData;
  ItemContainer(
      {super.key, required this.containerColor, required this.textData});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200,
      width: 100,
      decoration: BoxDecoration(
          color: containerColor,
          border: Border.all(width: 2),
          // border: Border.all(width: 20),
          borderRadius: const BorderRadius.all(Radius.circular(20))),
      child: Center(
          child: Text(
        textData,
        style: const TextStyle(color: Colors.white),
      )),
    );
  }
}
