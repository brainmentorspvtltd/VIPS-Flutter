import 'package:flutter/material.dart';
import 'package:nf_clone/screen/homePage.dart';

void main() {
  runApp(const MaterialApp(
    home: HomePage(),
  ));
}
