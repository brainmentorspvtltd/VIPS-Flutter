import 'package:flutter/material.dart';

class PREVIEW extends StatelessWidget {
  const PREVIEW({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Previews",
          style: TextStyle(
              color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold),
        ),
        const SizedBox(
          height: 5,
        ),
        SizedBox(
          // color: const Color.fromARGB(255, 40, 48, 40),
          width: double.infinity,
          height: 100,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: const [
              CircleAvatar(
                radius: 50,
                backgroundImage: AssetImage("assets/dogs.jpg"),
              ),
              CircleAvatar(
                radius: 50,
                backgroundImage: AssetImage("assets/stranger_things.jpg"),
              ),
              CircleAvatar(
                radius: 50,
                backgroundImage: AssetImage("assets/sintel.jpg"),
              ),
              CircleAvatar(
                radius: 50,
                backgroundImage: AssetImage("assets/thirteen_reasons.jpg"),
              ),
              CircleAvatar(
                radius: 50,
                backgroundImage: AssetImage("assets/witcher.jpg"),
              )
            ],
          ),
        )
      ],
    );
  }
}
