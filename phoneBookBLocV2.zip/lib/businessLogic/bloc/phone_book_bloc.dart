import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';
import 'package:phonebookbloc/data/respository/contactModle.dart';
import 'package:phonebookbloc/data/respository/phoneBookRepo.dart';

part 'phone_book_event.dart';
part 'phone_book_state.dart';

class PhoneBookBloc extends Bloc<PhoneBookEvent, PhoneBookState> {
  final PhoneBookRepo _phoneRepo;
  PhoneBookBloc(this._phoneRepo)
      : super(PhoneBookInitial(list: [ContactModel("", "")])) {
    on<CreateNewContactEvent>((event, emit) {
      print("this is the current state of the bloc $state");

      ContactModel contactMap =
          _phoneRepo.createContactMap(name: event.name, phone: event.phone);
      // Map<String, String> contactMap = {
      //   "name": event.name,
      //   "number": event.phone
      // };

      if (state is PhoneBookInitial) {
        emit(ContactAddedState(list: [contactMap]));
      } else if (state is ContactAddedState) {
        List<ContactModel> lastD = (state as ContactAddedState).list;
        print(
            "This is the last state list ${(state as ContactAddedState).list}");
        // lastData.addAll((state as ContactAddedState).list);
        emit(ContactAddedState(list: [...lastD, contactMap]));
      }

      // state.list

      // List<Map<String, String>> finalList = [lasteStatedata + contactMap];
    });
  }
}
