part of 'phone_book_bloc.dart';

@immutable
abstract class PhoneBookEvent {}

class CreateNewContactEvent extends PhoneBookEvent {
  final String name, phone;
  CreateNewContactEvent({required this.name, required this.phone});
}
