part of 'phone_book_bloc.dart';

@immutable
abstract class PhoneBookState {}

final class PhoneBookInitial extends PhoneBookState {
  final List<ContactModel> list;
  PhoneBookInitial({required this.list});
}

final class ContactAddedState extends PhoneBookState {
  final List<ContactModel> list;
  ContactAddedState({required this.list});
}
