class ContactModel {
  late String name, phone;

  ContactModel(this.name, this.phone);
  ContactModel.fromJSON(Map<String, String> json) {
    name = json['name']!;
    phone = json['number']!;
  }
}
