import 'package:phonebookbloc/data/respository/contactModle.dart';

class PhoneBookRepo {
  createContactMap({required String name, required String phone}) {
    Map<String, String> data = {"name": name, "number": phone};

    return ContactModel.fromJSON(data);
    return {"name": name, "number": phone};
  }
}
