import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:phonebookbloc/businessLogic/bloc/phone_book_bloc.dart';

class PhoneBookDemo extends StatefulWidget {
  const PhoneBookDemo({super.key});

  @override
  State<PhoneBookDemo> createState() => _PhoneBookDemoState();
}

class _PhoneBookDemoState extends State<PhoneBookDemo> {
  TextEditingController nameController = TextEditingController();
  TextEditingController phoneController = TextEditingController();

  showDialogBoxx() {
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: const Text("New Contact"),
            content: SizedBox(
              height: 100,
              // color: Colors.red,
              child: Column(
                children: [
                  TextField(
                    controller: nameController,
                    decoration:
                        const InputDecoration(hintText: "Enter the Name"),
                  ),
                  TextField(
                    keyboardType: TextInputType.number,
                    controller: phoneController,
                    decoration:
                        const InputDecoration(hintText: "Enter the Phone"),
                  )
                ],
              ),
            ),
            actions: [
              MaterialButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text("Cancel"),
              ),
              MaterialButton(
                onPressed: () {
                  BlocProvider.of<PhoneBookBloc>(context).add(
                      CreateNewContactEvent(
                          name: nameController.text,
                          phone: phoneController.text));
                  Navigator.pop(context);
                },
                child: const Text("Save Contact"),
              )
            ],
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
        title: const Text("Phone Book"),
        centerTitle: true,
      ),
      floatingActionButton: FloatingActionButton.extended(
          onPressed: () {
            showDialogBoxx();
          },
          label: const Text("Add Contact")),
      body: SizedBox(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        // color: Colors.amber,
        child: BlocBuilder<PhoneBookBloc, PhoneBookState>(
          builder: (context, state) {
            if (state is PhoneBookInitial) {
              return const Center(
                child: Text("No Contacts Found!"),
              );
            } else if (state is ContactAddedState) {
              print("this is the data from the state ${state.list}");
              return ListView.builder(
                  itemCount: state.list.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      tileColor: Colors.teal,
                      title: Text(state.list[index].name),
                      subtitle: Text(state.list[index].phone),
                    );
                  });
            }
            return const Center(child: Text("Some Error"));
          },
        ),
      ),
    ));
  }
}
